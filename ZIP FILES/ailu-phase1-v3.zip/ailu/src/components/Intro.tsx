"use client";
import dynamic from "next/dynamic";
import Image from "next/image";
import { AnimatePresence, motion } from "framer-motion";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { BRAND } from "@/lib/brand";

const HandScene = dynamic(() => import("./HandScene"), { ssr: false });
const KEY = "ailu-intro-seen";
const PROFILE_KEY = "ailu-visitor";

const WHO = ["Planning a celebration", "A company or organisation", "Part of a community or college", "A performer or creator", "Just exploring"];

function canUse3D() {
  try {
    const c = document.createElement("canvas");
    const gl = c.getContext("webgl2") || c.getContext("webgl");
    const mem = (navigator as Navigator & { deviceMemory?: number }).deviceMemory ?? 4;
    return !!gl && navigator.hardwareConcurrency > 4 && mem > 2;
  } catch { return false; }
}

// steps: 0 hand, 1 logo reveal, 2 welcome, 3 what we do, 4 about you
export default function Intro() {
  const router = useRouter();
  const [phase, setPhase] = useState<"pending" | "playing" | "done">("pending");
  const [step, setStep] = useState(0);
  const [reduced, setReduced] = useState(false);
  const [use3D, setUse3D] = useState(false);
  const [name, setName] = useState("");
  const [city, setCity] = useState("");
  const [who, setWho] = useState(WHO[0]);

  useEffect(() => {
    if (sessionStorage.getItem(KEY)) { setPhase("done"); return; }
    const rm = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    setReduced(rm);
    setUse3D(!rm && canUse3D());
    setPhase("playing");
    if (rm) { setStep(4); return; }
    const t = [setTimeout(() => setStep(1), 2200), setTimeout(() => setStep(2), 4600), setTimeout(() => setStep(3), 6600), setTimeout(() => setStep(4), 9000)];
    return () => t.forEach(clearTimeout);
  }, []);

  useEffect(() => { document.body.style.overflow = phase === "done" ? "" : "hidden"; return () => { document.body.style.overflow = ""; }; }, [phase]);

  function choose(intent: "events" | "join") {
    // Kept on this device only for now. Saving to a database needs a consent line first.
    try { localStorage.setItem(PROFILE_KEY, JSON.stringify({ name: name.trim(), city: city.trim(), who, intent })); } catch {}
    sessionStorage.setItem(KEY, "1");
    setPhase("done");
    router.push(intent === "events" ? "/events" : "/join");
  }
  const skip = () => { sessionStorage.setItem(KEY, "1"); setPhase("done"); };

  if (phase === "done") return null;
  const field = "mt-1 w-full rounded-lg border border-white/25 bg-white/10 px-3 py-3 text-ailu-cream placeholder:text-white/40";
  return (
    <AnimatePresence>
      <motion.div key="intro" className="fixed inset-0 z-50 flex flex-col items-center justify-center overflow-y-auto bg-ailu-black px-4 text-ailu-cream" exit={{ opacity: 0 }} transition={{ duration: 0.5 }} role="dialog" aria-label="Welcome to AILU">
        {phase === "playing" && (
          <>
            <button onClick={skip} className="absolute right-4 top-4 rounded-full border border-white/30 px-4 py-2 text-sm">Skip intro</button>

            {/* Hand first, then the logo reveals left to right so the hand lands as the U */}
            <div className="relative flex w-full max-w-3xl flex-col items-center">
              {step === 0 && (
                <motion.div className="relative h-56 w-56 sm:h-72 sm:w-72" initial={{ opacity: 0, scale: 0.85 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: reduced ? 0 : 1.6, ease: "easeOut" }}>
                  <div className="absolute inset-0 rounded-full bg-ailu-yellow/25 blur-3xl" aria-hidden />
                  {use3D ? <HandScene /> : <Image src={BRAND.hand} alt="AILU hand symbol" fill sizes="288px" className="object-contain" priority />}
                </motion.div>
              )}
              {step >= 1 && (
                <motion.div className="relative w-full" style={{ aspectRatio: BRAND.logoRatio }} initial={{ clipPath: "inset(0 100% 0 0)", opacity: 1 }} animate={{ clipPath: "inset(0 0% 0 0)" }} transition={{ duration: reduced ? 0 : 1.8, ease: "easeInOut" }}>
                  <Image src={BRAND.logo} alt="AILU" fill sizes="768px" className="object-contain" priority />
                </motion.div>
              )}
            </div>

            <div className="mt-6 min-h-[5rem] max-w-xl text-center">
              {step === 2 && <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="font-display text-2xl font-bold">Hi, welcome to AILU.</motion.p>}
              {step === 3 && <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-lg text-ailu-cream/85">We plan celebrations, open doors to opportunities, and stand beside people&apos;s dreams. {BRAND.tagline}</motion.p>}
            </div>

            {step >= 4 && (
              <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-lg pb-8">
                <h2 className="font-display text-xl font-bold">Tell us a little about you</h2>
                <p className="mt-1 text-sm text-ailu-cream/70">Optional. It helps us show you the right things. It stays on this device for now.</p>
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  <label className="block text-sm">Your name<input value={name} onChange={(e) => setName(e.target.value)} autoComplete="given-name" className={field} /></label>
                  <label className="block text-sm">City<input value={city} onChange={(e) => setCity(e.target.value)} autoComplete="address-level2" className={field} /></label>
                  <label className="block text-sm sm:col-span-2">I am<select value={who} onChange={(e) => setWho(e.target.value)} className={field}>{WHO.map((w) => <option key={w} className="text-black">{w}</option>)}</select></label>
                </div>
                <div className="mt-5 flex flex-col gap-3 sm:flex-row">
                  <button onClick={() => choose("events")} className="rounded-full bg-ailu-yellow px-7 py-3 font-semibold text-ailu-black">I am looking for events</button>
                  <button onClick={() => choose("join")} className="rounded-full border border-ailu-yellow px-7 py-3 font-semibold text-ailu-yellow">I want to join AILU</button>
                </div>
              </motion.div>
            )}
          </>
        )}
      </motion.div>
    </AnimatePresence>
  );
}
