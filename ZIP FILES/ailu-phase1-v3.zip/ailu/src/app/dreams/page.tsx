import { BRAND } from "@/lib/brand";
export const metadata = { title: "Fulfil Your Dreams | AILU" };

export default function Dreams() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-14">
      <h1 className="text-4xl font-extrabold">Fulfil your dreams</h1>
      <p className="mt-3 text-lg text-black/75">Some dreams wait because of money or circumstances. If you have one, tell us. When AILU is able to help, we help privately.</p>
      <h2 className="mt-8 text-2xl font-bold">Our promise</h2>
      <ul className="mt-3 list-disc space-y-2 pl-6">
        <li>Your story is never published or shared publicly. There are no public stories on this site.</li>
        <li>We help with dignity and respect.</li>
        <li>We will not ask for sensitive details such as identity documents or bank information.</li>
      </ul>
      <p className="mt-6 text-sm text-black/65">Sharing a dream does not guarantee it can be fulfilled. What we can do depends on suitability, safety and available resources. If the dreamer is under 18, a parent or guardian should be involved.</p>
      <p className="mt-6 rounded-lg bg-ailu-yellow/30 p-4">The private dream form opens soon. To reach us now, call <a className="font-semibold underline" href={`tel:${BRAND.phone.replace(/\s/g, "")}`}>{BRAND.phone}</a> or write to <a className="font-semibold underline" href={`mailto:${BRAND.email}`}>{BRAND.email}</a>.</p>
    </div>
  );
}
